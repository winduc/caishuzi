package cn.bdqn.dao;

import java.awt.print.Book;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import cn.bdqn.entity.Reader;
import cn.bdqn.utils.JdbcUtils;



public class BaseDao<T> {

	QueryRunner runner = new QueryRunner();
	private Class<T> type;
	@SuppressWarnings("unchecked")
	public BaseDao(){
		ParameterizedType p= (ParameterizedType)this.getClass().getGenericSuperclass();
		Type[] types=p.getActualTypeArguments();
		this.type=(Class<T>) types[0];
	}
	
	
public int update(String sql,Object...o){

	int count=0;
	Connection con =null;
	con=JdbcUtils.getConnection();
	try {
		count = runner.update(con, sql, o);
		JdbcUtils.close(null, null, con);
		//System.out.println(2);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		JdbcUtils.close(null, null, con);
	}
	JdbcUtils.close(null, null, con);
	return count;
}

public T getBean(String sql,Object...o){
	T t=null;
	Connection con=JdbcUtils.getConnection();
	try {
		t=runner.query(con, sql, new BeanHandler<T>(type),o);
		JdbcUtils.close(null, null, con);
		//System.out.println(3);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}finally {
		JdbcUtils.close(null, null, con);
	}
	JdbcUtils.close(null, null, con);
	return t;
	
	
}
public Reader getreader(String sql) throws SQLException{
	ResultSet rs = JdbcUtils.getConnection().prepareStatement(sql).executeQuery();
	while(rs.next()){
		Reader reader = new Reader(rs.getInt(1),
				rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5),rs.getString(6),
				rs.getInt(7),rs.getString(8),rs.getString(9));
		return reader;
	}
	return null;
	
}
public List<T> getBeans(String sql,Object...o){
	List<T> list=null;
	Connection con=JdbcUtils.getConnection();
	try {
		list=runner.query(con, sql, new BeanListHandler<T>(type),o);
		JdbcUtils.close(null, null, con);
		//System.out.println(4);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		JdbcUtils.close(null, null, con);
		
	}
	JdbcUtils.close(null, null, con);
	return list;
	
}
public static void main(String[] args) throws SQLException {
/*String sql = "SELECT * FROM bookinfo WHERE bookname='aa' LIMIT 0,10";
List list = (List)new BaseDao().getBeans(sql);
System.out.println(list);*/
	System.out.println(new BaseDao().getreader("select * from reader where username='aaa'"));
}







}
