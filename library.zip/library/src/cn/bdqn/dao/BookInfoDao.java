package cn.bdqn.dao;

import java.sql.Timestamp;
import java.util.List;

import cn.bdqn.entity.BookInfo;
import cn.bdqn.utils.Page;

public interface BookInfoDao {
int insertBook(BookInfo bookInfo);//����ͼ��

int delBook(int bookId);//ɾ��ͼ��

int updateBook(BookInfo bookInfo);//�޸�ͼ��

BookInfo getbookbybookid(Integer bookid);

int latecz(String bookname);

List<BookInfo> getBookList();//����ͼ����Ϣ

Page<BookInfo> getBookPage(Page<BookInfo> page);//��ҳ

 List getSearchResult(String bookname,String page);
 
 int getcounts(String bookname,String langu);
 
 int getallpage(String bookname,String langu);
 
 List borrowlist(String username);
 
 //int borrowbook(Integer bookid,String username,Timestamp time);
 
 List gethotlist();
 
 int backbook(Integer bookid,Timestamp time);

int borrowbook(Integer bookid, String username, Timestamp time, Timestamp times);

List getSearchResult(String bookname, String page, String langu);


}
