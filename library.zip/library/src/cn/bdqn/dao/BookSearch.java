package cn.bdqn.dao;

import java.awt.print.Book;
import java.util.List;

public interface BookSearch {


List<Book> search(String bookname, String page);
List<Book> borrowlist(String username);
}
