package cn.bdqn.dao.Impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import cn.bdqn.dao.BaseDao;
import cn.bdqn.dao.BookInfoDao;
import cn.bdqn.entity.BookInfo;
import cn.bdqn.utils.Page;

public class BookInfoDaoImpl extends BaseDao<BookInfo> implements BookInfoDao {

	@Override
	public int insertBook(BookInfo bookInfo) {
		String sql="insert into bookinfo (bookname,bookauthor,status,bookviews,borrower,borrowdate,returndate,langu) values(?,?,?,?,?,?,?,?)";
		return super.update(sql, bookInfo.getBookname(),bookInfo.getBookauthor(),bookInfo.getStatus(),bookInfo.getBookviews(),bookInfo.getBorrower(),bookInfo.getBorrowdate(),bookInfo.getReturndate(),bookInfo.getLangu());
		
		
	}

	@Override
	public int delBook(int bookId) {
		String sql="delete from bookinfo where bookid=?";
		
		
		
		return super.update(sql, bookId);
	}

	@Override
	public int updateBook(BookInfo bookInfo) {
		String sql="update bookinfo set bookname=?,bookauthor=?,langu=? where bookid=?";
		return super.update(sql, bookInfo.getBookname(),bookInfo.getBookauthor(),bookInfo.getLangu(),bookInfo.getBookid());
	}

	@Override
	public List<BookInfo> getBookList() {
		String sql="select * from bookinfo";
		return super.getBeans(sql);
	}

	@Override
	public Page<BookInfo> getBookPage(Page<BookInfo> page) {
		int totalRecord=this.getBookList().size();
		int totalPage=0;
		if (totalRecord%page.getPageSize()==0) {
			totalPage=totalRecord/page.getPageSize();
		}else{
			totalPage=totalRecord/page.getPageSize()+1;
		}
		int pageNum=0;
		if (page.getPageNum()>=totalPage) {
			pageNum=totalPage;
		}else if(page.getPageNum()<=0){
			pageNum=1;
		}else{
			pageNum=totalPage;
		}
		int index=(pageNum-1)*page.getPageSize();
		String sql="select * from bookinfo limit ?,?";
		Page<BookInfo> page1=new Page<BookInfo>(pageNum, page.getPageSize(), totalPage, totalRecord, index, super.getBeans(sql, index,page.getPageSize()));
		return page1;
	}

	@Override
	public List getSearchResult(String bookname,String page,String langu) {
		
		String sql = "select * from bookinfo where langu = '"+langu+"' and bookname like '%"+bookname+"%' limit "+(Integer.valueOf(page)-1)*5+",5";
		
		return super.getBeans(sql);
		
	}
	

	@Override
	public int getcounts(String bookname,String langu) {
		String sql = "select bookid from bookinfo where langu='"+langu+"' and bookname like '%"+bookname+"%'";
		List list = super.getBeans(sql);
		//System.out.println(list.size());
		
		return list.size();
	}

	@Override
	public int getallpage(String bookname,String langu) {
		String sql = "select bookid from bookinfo where langu='"+langu+"' and bookname like '%"+bookname+"%'";
		List list = super.getBeans(sql);
		
		return (list.size()-1)/5+1;
	}

	@Override
	public List<BookInfo> borrowlist(String username) {
		// TODO Auto-generated method stub
		String sql = "select * from bookinfo where borrower='"+username+"'";
		
		return super.getBeans(sql);
	}


	@Override
	public int latecz(String bookname) {//延长借书时间操作
		// TODO Auto-generated method stub
		String sql = "update bookinfo set ";
		return 0;
	}

	@Override
	public int borrowbook(Integer bookid,String username,Timestamp time,Timestamp times) {//借书操作
		// TODO Auto-generated method stub
		String sql = "update bookinfo set status=1,borrower='"+username+"',borrowdate='"+time+"',shoulddate='"+times+"',bookviews=bookviews+1 where bookid='"+bookid+"'";
		
		
		return super.update(sql);
		
		
	}

	@Override
	public BookInfo getbookbybookid(Integer bookid) {
	String sql = "select * from bookinfo where bookid='"+bookid+"'";
		return super.getBean(sql);
	}

	@Override
	public List gethotlist() {
		String sql = "select * from bookinfo order by bookviews desc limit 0,10";
		return super.getBeans(sql);
	}

	@Override
	public int backbook(Integer bookid,Timestamp time) {
		String sql = "update bookinfo SET STATUS=0,borrower=NULL,returndate='"+time+"',borrowdate=NULL,shoulddate=NULL WHERE bookid='"+bookid+"'";
		return super.update(sql);
	}

	@Override
	public List getSearchResult(String bookname, String page) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
