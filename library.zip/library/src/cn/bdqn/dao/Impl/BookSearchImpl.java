package cn.bdqn.dao.Impl;

import java.awt.print.Book;
import java.util.List;

import cn.bdqn.dao.BaseDao;
import cn.bdqn.dao.BookSearch;
import cn.bdqn.utils.JdbcUtils;

public class BookSearchImpl extends BaseDao implements BookSearch{

	@Override
	public List<Book> search(String bookname,String page) {
		String sql = "select * from bookinfo limit "+(Integer.valueOf(page)-1)*10+",10 where bookname="+bookname;
		return super.getBeans(sql);
	}
	
	
public static void main(String[] args) {
	System.out.println(new BookSearchImpl().search("aa", "1"));
}


@Override
public List<Book> borrowlist(String username) {
	// TODO Auto-generated method stub
	String sql = "select * from bookinfo where borrower="+username;
	
	return super.getBeans(sql);
}
	
}
