package cn.bdqn.dao.Impl;


import java.sql.SQLException;
import java.util.List;

import cn.bdqn.dao.BaseDao;
import cn.bdqn.dao.ReaderDao;
import cn.bdqn.entity.Reader;
import cn.bdqn.utils.Page;

public class ReaderDaoImpl extends BaseDao<Reader> implements ReaderDao{

	
    public List<Reader> getReader(){
    	String sql="select * from reader";
    	 
    	List<Reader> list=super.getBeans(sql);
    
		return list;
    }
	

	
	public Page<Reader> getReaderList(Page<Reader> page) {
		String sql="select * from reader limit ?,?";
		
		int totalRecord=this.getReader().size();
		
		int totalPage=0;
		int pageNum=0;
		
		
			totalPage=(totalRecord-1)%page.getPageSize()+1;
		
		if (page.getPageNum()>=totalPage) {
			pageNum=totalPage;
		}else if(page.getPageNum()>0){
			pageNum=page.getPageNum();
			
		}else{
			pageNum=1;
		}
		int index=(pageNum-1)*page.getPageSize();
	      
		List<Reader> list=super.getBeans(sql, index,page.getPageSize());
		
		Page<Reader> page1=new Page<Reader>(pageNum, page.getPageSize(), totalPage, totalRecord, index, list);
		
		return page1;
	
	}
	public Reader getReaderbyusername(String username){
		String sql = "select * from reader where username='"+username+"'";
		Reader reader = super.getBean(sql);
		return reader;
	}
	
	public int addReader(Reader reader){
		String sql = "insert into reader(username,password,age,sex,email,counts) values("
				+ "'"+reader.getUsername()+"',"+ "'"+reader.getPassword()+"',"+ "'"+reader.getAge()+"',"
				+ "'"+reader.getSex()+"',"+ "'"+reader.getEmail()+"'"
				+ ",'0')";
		
		
		
		
		return super.update(sql);
		
	}
	

	
	







public Reader getReaderbyemail(String email){
	String sql = "select * from reader where email='"+email+"'";
	Reader reader = super.getBean(sql);
	return reader;
}




public int getreaderbypwd(String username, String password, String email) throws SQLException {
	// TODO Auto-generated method stub
	String sql = "select * from reader where username='"+username+"' and password='"+password+"'";
	String sql1 = "SELECT * FROM reader WHERE email='"+email+"' AND PASSWORD='"+password+"'";
	Reader reader = super.getreader(sql);
	Reader reader1 = super.getreader(sql1);
	//System.out.println(33);
	if(reader==null && reader1==null){
		//System.out.println(44);
		return 3;
	}
		
	
	if(reader!=null&&reader.getPassword().equals(password)&&reader.getPassword()!=null){
		//System.out.println(321);
		
		return 1;
	} 
	else if(reader1!=null&&reader1.getPassword().equals(password)&&reader1.getPassword()!=null){
		//System.out.println(123);
		return 2;
		
	}
	return 3;
	

}



@Override
public int updateReader(Reader reader) {
	// TODO Auto-generated method stub
	String sql = "update reader set age = '"+reader.getAge()+"',password='"
	+reader.getPassword()+"' where username='"+reader.getUsername()+"'";
	
	
	return super.update(sql);
}
public static void main(String[] args) {
	Reader reader = new Reader();
	reader.setUsername("aaa");
	reader.setPassword("112");
	reader.setAge(11);
	new ReaderDaoImpl().updateReader(reader);
}



@Override
public int delReader(String username) {
	// TODO Auto-generated method stub
	
	
	
	
	String sql = "delete from reader where username='"+username+"'";
	
	return super.update(sql);
}



@Override
public boolean zhuxiaoyanzheng(String username) {
	// TODO Auto-generated method stub
	String sql = "select * from bookinfo where borrower='"+username+"'";
	List list = super.getBeans(sql);
	if(list.size()==0){
		return true;
		
	}
	
	return false;
}
public int zengjiashu(String username){
	String sql = "update reader set counts=counts+1 where username='"+username+"'";
	return super.update(sql);
}
public int jianshaoshu(String username){
	String sql = "update reader set counts=counts-1 where username='"+username+"'";
	return super.update(sql);
}
}
