package cn.bdqn.dao.Impl;



import java.util.List;

import cn.bdqn.dao.BaseDao;
import cn.bdqn.dao.SystemManagerDao;
import cn.bdqn.entity.SystemManager;
import cn.bdqn.utils.Page;

public class SystemManagerDaoImpl extends BaseDao<SystemManager> implements SystemManagerDao {

	@Override
	public SystemManager systemLogin(SystemManager systemManager) {
		String sql="select username,password from systemmanager where username=? and password=?";
		return super.getBean(sql, systemManager.getUsername(),systemManager.getPassword());
		
		
		 
	}

	@Override
	public int insertManager(SystemManager systemManager) {
		String sql="insert into systemmanager (username,password)values(?,?)";
		
		return super.update(sql, systemManager.getUsername(),systemManager.getPassword());
	}

	

	@Override
	public int updateManager(SystemManager systemManager) {
		String sql="update systemmanager set username=?,password=? where id=?";
		
		return super.update(sql, systemManager.getUsername(),systemManager.getPassword(),systemManager.getId());
	}

	@Override
	public List<SystemManager> selectManagerList() {
		String sql="select * from systemmanager";
		
		return super.getBeans(sql);
	}

	@Override
	public Page<SystemManager> selectManager(Page<SystemManager> page) {
		String sql="select * from systemmanager limit ?,?";
		int totalRecord=this.selectManagerList().size();
		int totalPage=0;
		int pageNum=0;
		if (totalRecord%page.getPageSize()==0) {
			totalPage=totalRecord/page.getPageSize();
		}else{
			totalPage=totalRecord/page.getPageSize()+1;
		}
		if (page.getPageNum()>=totalPage) {
			pageNum=totalPage;
		}else if(page.getPageNum()<=0){
			pageNum=1;
		}else{
			pageNum=page.getPageNum();
		}
		int index=(pageNum-1)*page.getPageSize();
		
		Page<SystemManager> page1=new Page<SystemManager>(pageNum, page.getPageSize(), totalPage, totalRecord, index, super.getBeans(sql, index,page.getPageSize()));
		return page1;
	}

	@Override
	public SystemManager isExistUN(SystemManager systemManager) {
		String sql="select username from systemmanager where username=?";
		return super.getBean(sql, systemManager.getUsername());
	}

	@Override
	public int yanqi(String bookid) {
		String sql = "UPDATE bookinfo SET shoulddate = DATE_ADD(shoulddate, INTERVAL 30 DAY),STATUS=2 WHERE bookid="+bookid+";";
		
		return super.update(sql);
	}

	
	

}
