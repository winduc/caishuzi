package cn.bdqn.dao.Impl;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.List;

import cn.bdqn.dao.BaseDao;
import cn.bdqn.dao.discussDao;
import cn.bdqn.entity.bookscore;
import cn.bdqn.entity.discuss;

public class bookscoreimpl  extends BaseDao<bookscore> {
	public String  getscore(String bookname) {
		//String sql = "select avg(score) from discuss where bookname='"+bookname+"'";
		String sql1 = "select * from bookscore where bookname='"+bookname+"'";
		List<bookscore> sclist = super.getBeans(sql1);
		int s = 0;
		if(sclist.size()==0){
			return "5";
		}
		
		for(int u =0;u<sclist.size();u++){
			s=s+sclist.get(u).getScore();
			
		}
		double zongshu = s/sclist.size();
		DecimalFormat dd = new DecimalFormat("#.0");
		
		
		return dd.format(zongshu);
	}
	public int dafen(String bookname,String username,String score){
		//String sql ="INSERT INTO bookscore(bookname,username,score) SELECT '"+bookname+"','"+username+"','"+score+"' FROM bookscore"+
		
		//" WHERE NOT EXISTS (SELECT scoreid FROM bookscore WHERE bookname='"+bookname+"' AND username='"+username+"')";
		String sql = "insert into bookscore(bookname,username,score) values('"+bookname+"','"+username+"','"+score+"')";
		return super.update(sql); 
		
	}
	public boolean getusername(String bookname,String username){
		String sql = "select scoreid from bookscore where bookname='"+bookname+"' and username='"+username+"'";
		bookscore boo = super.getBean(sql);
		if(boo==null){
			return false;
		}else{
		
		
		return true;
		}
	}
	
	
	
}
