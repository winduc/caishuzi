package cn.bdqn.dao.Impl;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.List;

import cn.bdqn.dao.BaseDao;
import cn.bdqn.dao.discussDao;
import cn.bdqn.entity.bookscore;
import cn.bdqn.entity.discuss;

public class discussDaoImpl extends BaseDao<discuss> implements discussDao{

	@Override
	public int adddiscuss(String bookname, String content, Integer score, Timestamp senddate,String username) {
		// TODO Auto-generated method stub
		String sql = "insert into discuss (bookname,content,score,senddate,username) "
				+ "values('"+bookname+"','"+content+"','"+score+"','"+senddate+"','"+username+"')";
		return super.update(sql);
	}

	@Override
	public List<discuss> getdiscusslist(String bookname,String page) {
	String sql = "select * from discuss where bookname='"+bookname+"' limit "+(Integer.valueOf(page)-1)*10+",10";
	
	
		return super.getBeans(sql);
	}

	@Override
	public String  getscore(String bookname) {
		//String sql = "select avg(score) from discuss where bookname='"+bookname+"'";
		String sql1 = "select * from bookscore where bookname='"+bookname+"'";
		List<discuss> sclist = super.getBeans(sql1);
		int s = 0;
		if(sclist.size()==0){
			return "0";
		}
		
		for(int u =0;u<sclist.size();u++){
			s=s+sclist.get(u).getScore();
			
		}
		double zongshu = s/sclist.size();
		DecimalFormat dd = new DecimalFormat("#.0");
		
		
		return dd.format(zongshu);
	}

	@Override
	public int getallpage(String bookname) {
		int i = new discussDaoImpl().getcounts(bookname);
		
		return ((i-1)/10+1);
	}

	@Override
	public int getcounts(String bookname) {
		String sql = "select * from discuss where bookname='"+bookname+"'";
		List<discuss> sclist = super.getBeans(sql);
		
		return sclist.size();
	}
	
}
