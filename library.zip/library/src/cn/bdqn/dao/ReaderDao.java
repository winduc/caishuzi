package cn.bdqn.dao;



import java.sql.SQLException;
import java.util.List;

import cn.bdqn.entity.Reader;
import cn.bdqn.utils.Page;

public interface ReaderDao {

List<Reader> getReader();
Page<Reader> getReaderList(Page<Reader> page);
int getreaderbypwd(String username,String password,String email) throws SQLException;
Reader getReaderbyusername(String username);
Reader getReaderbyemail(String email);
int addReader(Reader reader);
int updateReader(Reader reader);
int delReader(String username);
boolean zhuxiaoyanzheng(String username);
public int zengjiashu(String username);
}
