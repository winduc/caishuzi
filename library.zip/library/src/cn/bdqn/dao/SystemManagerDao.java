package cn.bdqn.dao;

import java.util.List;

import cn.bdqn.entity.SystemManager;
import cn.bdqn.utils.Page;

public interface SystemManagerDao {
SystemManager systemLogin(SystemManager systemManager);
int insertManager(SystemManager systemManager);

int updateManager(SystemManager systemManager);

List<SystemManager> selectManagerList();

Page<SystemManager> selectManager(Page<SystemManager> page);

SystemManager isExistUN(SystemManager systemManager);

int yanqi(String bookid);
}
