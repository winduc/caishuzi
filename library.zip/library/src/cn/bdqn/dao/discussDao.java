package cn.bdqn.dao;

import java.sql.Timestamp;
import java.util.List;

public interface discussDao {
int adddiscuss(String bookname,String content,Integer score,Timestamp senddate,String username);

List getdiscusslist(String bookname,String page);

String getscore(String bookname);

int getallpage(String bookname);

int getcounts(String bookname);

}
