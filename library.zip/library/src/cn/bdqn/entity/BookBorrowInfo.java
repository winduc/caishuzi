package cn.bdqn.entity;

public class BookBorrowInfo {
	 
	 private Integer id;
	 private String  bookname;
	 private String leibie;
	 private String borrower;
	 private String borrowdate;
	 private String returndate;
	public BookBorrowInfo(Integer id, String bookname, String leibie, String borrower, String borrowdate, String returndate) {
		super();
		this.id = id;
		this.bookname = bookname;
		this.leibie = leibie;
		this.borrower = borrower;
		this.borrowdate = borrowdate;
		this.returndate = returndate;
	}
	public BookBorrowInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getLeibie() {
		return leibie;
	}
	public void setLeibie(String leibie) {
		this.leibie = leibie;
	}
	public String getBorrower() {
		return borrower;
	}
	public void setBorrower(String borrower) {
		this.borrower = borrower;
	}
	public String getBorrowdate() {
		return borrowdate;
	}
	public void setBorrowdate(String borrowdate) {
		this.borrowdate = borrowdate;
	}
	public String getReturndate() {
		return returndate;
	}
	public void setReturndate(String returndate) {
		this.returndate = returndate;
	}
	@Override
	public String toString() {
		return "BookInfo [id=" + id + ", bookname=" + bookname + ", leibie=" + leibie + ", borrower=" + borrower
				+ ", borrowdate=" + borrowdate + ", returndate=" + returndate + "]";
	}
	 
	 
}
        