package cn.bdqn.entity;

import java.util.Date;

public class BookInfo {
private Integer bookid;
private String bookname;
private String bookauthor;
private Integer status;
private Integer  bookviews;
public BookInfo(Integer bookid, String bookname, String bookauthor, Integer status, Integer bookviews, String borrower,
		Date borrowdate, Date returndate, Date shoulddate, String imgpath, Integer langu) {
	super();
	this.bookid = bookid;
	this.bookname = bookname;
	this.bookauthor = bookauthor;
	this.status = status;
	this.bookviews = bookviews;
	this.borrower = borrower;
	this.borrowdate = borrowdate;
	this.returndate = returndate;
	this.shoulddate = shoulddate;
	this.langu = langu;
	this.imgpath = imgpath;
}
private String borrower;
private Date borrowdate;
private Date returndate;
private Date shoulddate;
public Integer getLangu() {
	return langu;
}
public void setLangu(Integer langu) {
	this.langu = langu;
}
private Integer langu;
public Date getShoulddate() {
	return shoulddate;
}
public void setShoulddate(Date shoulddate) {
	this.shoulddate = shoulddate;
}
private String imgpath;
public BookInfo() {
	super();
	// TODO Auto-generated constructor stub
}

public String getImgpath() {
	return imgpath;
}
public void setImgpath(String imgpath) {
	this.imgpath = imgpath;
}
public Integer getBookid() {
	return bookid;
}
public void setBookid(Integer bookid) {
	this.bookid = bookid;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public String getBookauthor() {
	return bookauthor;
}
public void setBookauthor(String bookauthor) {
	this.bookauthor = bookauthor;
}
public Integer getStatus() {
	return status;
}
public void setStatus(Integer status) {
	this.status = status;
}
public Integer getBookviews() {
	return bookviews;
}
public void setBookviews(Integer bookviews) {
	this.bookviews = bookviews;
}
public String getBorrower() {
	return borrower;
}
public void setBorrower(String borrower) {
	this.borrower = borrower;
}
public Date getBorrowdate() {
	return borrowdate;
}
public void setBorrowdate(Date borrowdate) {
	this.borrowdate = borrowdate;
}
public Date getReturndate() {
	return returndate;
}
public void setReturndate(Date returndate) {
	this.returndate = returndate;
}
@Override
public String toString() {
	return "BookInfo [bookid=" + bookid + ", bookname=" + bookname + ", bookauthor=" + bookauthor + ", status=" + status
			+ ", bookviews=" + bookviews + ", borrower=" + borrower + ", borrowdate=" + borrowdate + ", returndate="
			+ returndate + ", shoulddate=" + shoulddate + ", langu=" + langu + ", imgpath=" + imgpath + "]";
}


}
              