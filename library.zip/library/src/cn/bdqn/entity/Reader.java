package cn.bdqn.entity;

import java.util.List;

public class Reader {
	
private Integer id;
private String username;
private String password;
private  Integer age;
private String sex;
private String email;
private Integer style;
private String history;
private String borrowbook;
private Integer counts;

public Integer getCounts() {
	return counts;
}
public void setCounts(Integer counts) {
	this.counts = counts;
}
public Reader() {
	super();
	// TODO Auto-generated constructor stub
}
public Reader(Integer id, String username, String password, Integer age, String sex, String email, Integer style,
		String history, String borrowbook) {
	super();
	this.id = id;
	this.username = username;
	this.password = password;
	this.age = age;
	this.sex = sex;
	this.email = email;
	this.style = style;
	this.history = history;
	this.borrowbook = borrowbook;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Integer getAge() {
	return age;
}
public void setAge(Integer age) {
	this.age = age;
}
public String getSex() {
	return sex;
}
public void setSex(String sex) {
	this.sex = sex;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public Integer getStyle() {
	return style;
}
public void setStyle(Integer style) {
	this.style = style;
}
public String getHistory() {
	return history;
}
public void setHistory(String history) {
	this.history = history;
}
public String getBorrowbook() {
	return borrowbook;
}
public void setBorrowbook(String borrowbook) {
	this.borrowbook = borrowbook;
}
@Override
public String toString() {
	return "Reader [id=" + id + ", username=" + username + ", password=" + password + ", age=" + age + ", sex=" + sex
			+ ", email=" + email + ", style=" + style + ", history=" + history + ", borrowbook=" + borrowbook + "]";
}




}
