package cn.bdqn.entity;

public class bookscore {
private String bookname;
private String username;
public bookscore() {
	super();
	// TODO Auto-generated constructor stub
}
public bookscore(String bookname, String username, Integer score) {
	super();
	this.bookname = bookname;
	this.username = username;
	this.score = score;
}
@Override
public String toString() {
	return "bookscore [bookname=" + bookname + ", username=" + username + ", score=" + score + "]";
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public Integer getScore() {
	return score;
}
public void setScore(Integer score) {
	this.score = score;
}
private Integer score;
}
