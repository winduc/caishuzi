package cn.bdqn.entity;

import java.sql.Timestamp;

public class discuss {
private Integer discussid;
private String username;
private String bookname;
private String content;
private Timestamp senddate;
private Integer score;
private Integer good;
private Integer bad;
public Integer getDiscussid() {
	return discussid;
}
public void setDiscussid(Integer discussid) {
	this.discussid = discussid;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public String getContent() {
	return content;
}
public void setContent(String content) {
	this.content = content;
}
public Timestamp getSenddate() {
	return senddate;
}
public void setSenddate(Timestamp senddate) {
	this.senddate = senddate;
}
public Integer getScore() {
	return score;
}
public void setScore(Integer score) {
	this.score = score;
}
public Integer getGood() {
	return good;
}
public void setGood(Integer good) {
	this.good = good;
}
public Integer getBad() {
	return bad;
}
public void setBad(Integer bad) {
	this.bad = bad;
}
@Override
public String toString() {
	return "score [discussid=" + discussid + ", username=" + username + ", bookname=" + bookname + ", content="
			+ content + ", senddate=" + senddate + ", score=" + score + ", good=" + good + ", bad=" + bad + "]";
}
public discuss(Integer discussid, String username, String bookname, String content, Timestamp senddate, Integer score,
		Integer good, Integer bad) {
	super();
	this.discussid = discussid;
	this.username = username;
	this.bookname = bookname;
	this.content = content;
	this.senddate = senddate;
	this.score = score;
	this.good = good;
	this.bad = bad;
}
public discuss(){
	super();
}


}
