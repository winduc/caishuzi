package cn.bdqn.service.Impl;



import java.sql.Timestamp;

import cn.bdqn.entity.BookInfo;
import cn.bdqn.utils.Page;

public interface BookInfoService {
	int insertBook(BookInfo bookInfo);//����ͼ��

	int delBook(int bookId);//ɾ��ͼ��

	int updateBook(BookInfo bookInfo);//�޸�ͼ��

	Page<BookInfo> getBookPage(String pageNum,String pageSize);//��ҳ
	
	int borrowbook(Integer bookid,String username);
	
	int backbook(Integer bookid,Timestamp time);
}
