package cn.bdqn.service.Impl;

import java.sql.Timestamp;

import cn.bdqn.dao.BookInfoDao;
import cn.bdqn.dao.Impl.BookInfoDaoImpl;
import cn.bdqn.entity.BookInfo;
import cn.bdqn.utils.Page;

public class BookInfoServiceImpl implements BookInfoService {
	BookInfoDao bookInfoDao =new BookInfoDaoImpl();
	
	@Override
	public int insertBook(BookInfo bookInfo) {
		// TODO Auto-generated method stub
		return bookInfoDao.insertBook(bookInfo);
	}

	@Override
	public int delBook(int bookId) {
		// TODO Auto-generated method stub
		return bookInfoDao.delBook(bookId);
	}

	@Override
	public int updateBook(BookInfo bookInfo) {
		// TODO Auto-generated method stub
		return bookInfoDao.updateBook(bookInfo);
	}

	@Override
	public Page<BookInfo> getBookPage(String pageNum, String pageSize) {
		// TODO Auto-generated method stub
		int pageNumInt=Integer.parseInt(pageNum);
		int pageSizeInt=Integer.parseInt(pageSize);
		Page<BookInfo> page=new Page<>(pageNumInt, pageSizeInt, 0, 0, 0, null);
		return bookInfoDao.getBookPage(page);
	}

	@Override
	public int borrowbook(Integer bookid, String username) {
		// TODO Auto-generated method stub
		return bookInfoDao.borrowbook(bookid, username, null,null);
	}

	@Override
	public int backbook(Integer bookid, Timestamp time) {
		// TODO Auto-generated method stub
		return bookInfoDao.backbook(bookid, time);
	}

}
