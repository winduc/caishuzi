package cn.bdqn.service.Impl;

import java.util.List;

public interface BookSearchService {
List getbook(String bookname,String page);
}
