package cn.bdqn.service.Impl;

import cn.bdqn.entity.Reader;
import cn.bdqn.utils.Page;

public interface ReaderService {
	Page<Reader> getReaderList(String pageNum,String pageSize);
	boolean getReaderbyyhmandpwd(String id,String password,String email);
	int zengjiashu(String username);
	int addReader(Reader reader);
}
