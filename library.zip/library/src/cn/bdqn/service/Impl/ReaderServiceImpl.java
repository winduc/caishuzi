package cn.bdqn.service.Impl;

import java.sql.SQLException;

import cn.bdqn.dao.BaseDao;
import cn.bdqn.dao.ReaderDao;
import cn.bdqn.dao.Impl.ReaderDaoImpl;
import cn.bdqn.entity.Reader;
import cn.bdqn.utils.Page;

public class ReaderServiceImpl implements ReaderService {
    ReaderDao readerDao=new ReaderDaoImpl();
	@Override
	public Page<Reader> getReaderList(String pageNum, String pageSize) {
		int pageNumInt=Integer.parseInt(pageNum);
		int pageSizeInt=Integer.parseInt(pageSize);
		Page<Reader> page=new Page<>(pageNumInt, pageSizeInt, 0, 0, 0, null);
		return readerDao.getReaderList(page);
	}
@Override
	public boolean getReaderbyyhmandpwd(String username, String password,String email) {

		try {
			if(readerDao.getreaderbypwd(username, password, email)==1){
				return true;
				
			}else if(readerDao.getreaderbypwd(username, password, email)==2){
				return true;
			}else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			return false;
	}
	@Override
	public int addReader(Reader reader) {
		// TODO Auto-generated method stub
		return readerDao.addReader(reader);
	}
	public Reader getReader(String username,String email,String password) throws SQLException {
		if(readerDao.getreaderbypwd(username, password, email)==1){
			return readerDao.getReaderbyusername(username);
		}else if(readerDao.getreaderbypwd(username, password, email)==2){
			return readerDao.getReaderbyemail(email);
		}
		
		return null;
	}
	public static void main(String[] args) throws SQLException {
		//System.out.println(new ReaderServiceImpl().getReader("a","a","123"));
	
		System.out.println(new BaseDao().getreader("select * from reader where username='aaa'").getUsername());
	}
	public int updatereader(Reader reader){
		return readerDao.updateReader(reader);
		
	}
public int delreader(String username){
	return readerDao.delReader(username);
}
@Override
public int zengjiashu(String username) {
	String sql = "update reader set counts=counts+1 where username='"+username+"'";
	
	return readerDao.zengjiashu(username);
}
}
