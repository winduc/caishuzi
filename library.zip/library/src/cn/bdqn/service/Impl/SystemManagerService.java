package cn.bdqn.service.Impl;

import cn.bdqn.entity.SystemManager;
import cn.bdqn.utils.Page;

public interface SystemManagerService {
boolean systemLogin(SystemManager systemManager);
int insertManager(SystemManager systemManager);

int updateManager(SystemManager systemManager);

Page<SystemManager> selectManager(String pageNum,String pageSize);

boolean isExistUN(SystemManager systemManager);
}
