package cn.bdqn.service.Impl;


import cn.bdqn.dao.SystemManagerDao;
import cn.bdqn.dao.Impl.SystemManagerDaoImpl;
import cn.bdqn.entity.SystemManager;
import cn.bdqn.utils.Page;

public class SystemManagerServiceImpl  implements SystemManagerService {
    SystemManagerDao systemManagerDao=new SystemManagerDaoImpl();
	@Override
	public boolean systemLogin(SystemManager systemManager) {
		if (systemManagerDao.systemLogin(systemManager)!=null) {
			return true;
		}else{
		return false;
		}
	}
	@Override
	public int insertManager(SystemManager systemManager) {
		
		return systemManagerDao.insertManager(systemManager);
	}
	
	@Override
	public int updateManager(SystemManager systemManager) {
		// TODO Auto-generated method stub
		return systemManagerDao.updateManager(systemManager);
	}
	@Override
	public Page<SystemManager> selectManager(String pageNum,String pageSize) {
		int pageNumInt=Integer.parseInt(pageNum);
		int pageSizeInt=Integer.parseInt(pageSize);
		Page<SystemManager> page=new Page<>(pageNumInt, pageSizeInt, 0, 0, 0, null);
		return systemManagerDao.selectManager(page);
	}
	@Override
	public boolean isExistUN(SystemManager systemManager) {
		if (systemManagerDao.isExistUN(systemManager)!=null) {
			return true;
		}else{
		    return false;
		}
	}

}
