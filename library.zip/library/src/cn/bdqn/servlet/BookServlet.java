package cn.bdqn.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.BookInfoDaoImpl;
import cn.bdqn.entity.Reader;

/**
 * Servlet implementation class BookServlet
 */
@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
	protected void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	request.setCharacterEncoding("utf-8");
	String page = ((request.getParameter("page")!=null)?(request.getParameter("page")+""):"1");
	String bookname = request.getParameter("bookname");
	//String langu = ((request.getParameter("langu")!=null)?(request.getParameter("langu")+""):"0");
	String langu = request.getParameter("langu");
	//System.out.println(langu);
	int zongshu = new BookInfoDaoImpl().getcounts(bookname,langu);
	
	List list = new BookInfoDaoImpl().getSearchResult(bookname, page,langu);
	List hotlist = new BookInfoDaoImpl().gethotlist();
	request.getSession().setAttribute("hotlist", hotlist);
	int allpage =new BookInfoDaoImpl().getallpage(bookname,langu);
	request.setAttribute("booklist", list);
	//System.out.println(list);
	request.setAttribute("bookname", bookname);
	request.setAttribute("page", page);
	//request.setAttribute("chushi", chushi);
	request.setAttribute("zongshu", zongshu);
	request.setAttribute("sousuo", bookname);
	request.setAttribute("allpage", allpage);
	request.getRequestDispatcher("Book.jsp").forward(request, response);
	//System.out.println(allpage);
	//System.out.println(zongshu);
	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		search(request, response);
		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		search(request, response);
			
		}
	
}
