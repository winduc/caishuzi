package cn.bdqn.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.BookInfoDaoImpl;
import cn.bdqn.dao.Impl.ReaderDaoImpl;
import cn.bdqn.entity.BookInfo;
import cn.bdqn.entity.Reader;

import cn.bdqn.service.Impl.ReaderService;
import cn.bdqn.service.Impl.ReaderServiceImpl;

/**
 * Servlet implementation class Readerservlet
 */
@WebServlet("/Readerservlet")
public class Readerservlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	request.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
	if(method.equals("login")){
		try {
			login(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}else if(method.equals("regist")){
			regist(request, response);
			
		}/*else if(method.equals("outlogin")){
			outlogin(request, response);
		}
	*/
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void regist(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//String id=request.getParameter("id");
		//验证码
		String yzm  = (String)request.getSession().getAttribute(com.google.code.kaptcha.Constants.KAPTCHA_SESSION_KEY);
		String yhyzm = request.getParameter("yhyzm");
		if(!yzm.equals(yhyzm)){
			request.setAttribute("yzmcw", "验证码错误！");
			request.setAttribute("yzmcw2", "1");
			request.getRequestDispatcher("regist1.jsp").forward(request, response);
		}
		
		String pwd = request.getParameter("pwd");
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String sex = request.getParameter("sex");
		String age1 = request.getParameter("age");
		//验证是否存在
		Reader readerem = new ReaderDaoImpl().getReaderbyemail(email);
		Reader readerus = new ReaderDaoImpl().getReaderbyusername(username);
		if(readerem!=null){
			request.setAttribute("cunzai1","邮箱已被注册！");
			request.setAttribute("yzmcw2", "2");
			request.getRequestDispatcher("regist1.jsp").forward(request, response);
		}
		if(readerus!=null){
			request.setAttribute("cunzai2", "用户名已存在！");
			request.setAttribute("yzmcw2", "3");
			request.getRequestDispatcher("regist1.jsp").forward(request, response);
		}else{
		int age = Integer.valueOf(age1);
		Reader reader = new Reader(null,username,pwd,age,sex,email,null,null,null);
		new ReaderServiceImpl().addReader(reader);
		request.getSession().setAttribute("reader",reader);
		
		request.getRequestDispatcher("zccg.jsp").forward(request, response);
		}
	}
	public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException{
		String email = request.getParameter("username");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		
		
		if(new ReaderServiceImpl().getReaderbyyhmandpwd(username, password, email)){
			Reader reader =  new ReaderServiceImpl().getReader(username, email, password);
			List borrowlist = new BookInfoDaoImpl().borrowlist(reader.getUsername());
			request.getSession().setAttribute("borrowlist", borrowlist);
			request.getSession().setAttribute("reader",reader);
			request.getSession().setAttribute("username", reader.getUsername());
			request.getRequestDispatcher("mainpage.jsp").forward(request, response);
			if(reader.getCounts()==5){
				request.getSession().setAttribute("jinz", false);
				
			}
		}else{
			String flag ="帐号或密码错误";
			
			request.setAttribute("flag",flag);
			request.getRequestDispatcher("regist1.jsp").forward(request, response);
		}
	
	}
	public void outlogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
	
		//Reader reader = new Reader();
		request.getSession().invalidate();
		response.sendRedirect("mainpage.jsp");
	
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
	outlogin(request, response);	 
	}
}
