package cn.bdqn.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.entity.BookInfo;
import cn.bdqn.entity.Reader;
import cn.bdqn.entity.SystemManager;
import cn.bdqn.service.Impl.BookInfoService;
import cn.bdqn.service.Impl.BookInfoServiceImpl;
import cn.bdqn.service.Impl.ReaderService;
import cn.bdqn.service.Impl.ReaderServiceImpl;
import cn.bdqn.service.Impl.SystemManagerService;
import cn.bdqn.service.Impl.SystemManagerServiceImpl;
import cn.bdqn.utils.Page;
import cn.bdqn.utils.WebUtils;

/**
 * Servlet implementation class SystemManagerServlet
 */
@WebServlet("/SystemManagerServlet")
public class SystemManagerServlet extends BaseServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	SystemManagerService smsi=new SystemManagerServiceImpl();//����Ա��¼���˻�������
	ReaderService rs=new ReaderServiceImpl();             //�����б�չ��
	BookInfoService bis=new BookInfoServiceImpl();        //ͼ����Ϣ����
	//�޸ĺ����ӹ���Ա
	protected boolean update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		SystemManager systemManager=WebUtils.param2Bean(req, new SystemManager());
		if (systemManager.getId()>0) {
			smsi.updateManager(systemManager);
		}else{
			if (smsi.isExistUN(systemManager)) {
				req.setAttribute("msg", "�ù���Ա�Ѵ��ڣ����������ӣ�");
				req.getRequestDispatcher("/SYSTEM/manager/update_manager.jsp").forward(req, resp);
				return false;
			}else{
				smsi.insertManager(systemManager);
			}
		}
		resp.sendRedirect("/library/SystemManagerServlet?method=selectManager&pageNum=1&pageSize=3");
		return false;
	}
	
	//����Ա��¼
	protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		SystemManager systemManager=WebUtils.param2Bean(req, new SystemManager());
		if (smsi.systemLogin(systemManager)) {
			resp.sendRedirect("/library/SYSTEM/main/mainPage.jsp");
		}else{
			req.setAttribute("msg", "�û������������");
			req.getRequestDispatcher("/SYSTEM/login/login.jsp").forward(req, resp);
		}
		
	}
	
	//��ȡ���޸ĵĹ���Ա��Ϣ
	protected void getManager(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username=req.getParameter("username");
		String password=req.getParameter("password");
		String id=req.getParameter("id");
	
		int idInt=Integer.parseInt(id);
	
		SystemManager systemManager=new SystemManager(idInt, username, password);
		req.setAttribute("manager", systemManager);
		req.getRequestDispatcher("/SYSTEM/manager/update_manager.jsp").forward(req, resp);
	}
	
	//��ѯ����Ա
	
	protected void selectManager(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String pageNum=req.getParameter("pageNum");
		String pageSize=req.getParameter("pageSize");
		Page<SystemManager> page= smsi.selectManager(pageNum, pageSize);
		List<SystemManager> list=page.getData();
		req.setAttribute("page", page);
		req.setAttribute("list", list);
		req.getRequestDispatcher("/SYSTEM/manager/select.jsp").forward(req, resp);
	}
	
	//�û��б�չʾ
	protected void showReader(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pageNum=request.getParameter("pageNum");
		String pageSize=request.getParameter("pageSize");
		if (pageNum==null) {
			pageNum="1";
		}
		if (pageSize==null) {
			pageSize="3";
		}
		Page<Reader> page=rs.getReaderList(pageNum, pageSize);
		List<Reader> list=page.getData();
		request.setAttribute("page", page);
		request.setAttribute("readerList", list);
		request.getRequestDispatcher("/SYSTEM/reader_manage/readerlist_show.jsp").forward(request, response);
	}

	
	//ͼ����Ϣ����

	protected void insertBook(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	}
	
	//ɾ��ͼ��
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String bookid=req.getParameter("id");
		int bookId=Integer.parseInt(bookid);
		bis.delBook(bookId);
		
	}
	
	//ͼ���ҳ
	protected void getBookList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	    String pageNum=request.getParameter("pageNum");
	    String pageSize=request.getParameter("pageSize");
	    if (pageNum==null) {
			pageNum="1";
		}
	    if (pageSize==null) {
			pageSize="3";
		}
	    Page<BookInfo> page= bis.getBookPage(pageNum, pageSize);
	    List<BookInfo> list=  page.getData();
	    request.setAttribute("page", page);
	    request.setAttribute("list", list);
	    request.getRequestDispatcher("/SYSTEM/bookinfo/bookinfo_show.jsp").forward(request, response);
	}
}
