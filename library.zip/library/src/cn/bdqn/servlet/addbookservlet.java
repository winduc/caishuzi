package cn.bdqn.servlet;

import java.awt.print.Book;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.BookInfoDaoImpl;
import cn.bdqn.entity.BookInfo;

/**
 * Servlet implementation class addbookservlet
 */
@WebServlet("/addbookservlet")
public class addbookservlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String bookauthor = request.getParameter("bookauthor");
		String bookname = request.getParameter("bookname");
		String imgpath = request.getParameter("imgpath");
		String langu = request.getParameter("langu");
				BookInfo book = new BookInfo(null,bookname,bookauthor,0,0,null,null,null,null,imgpath,Integer.valueOf(langu));
		new BookInfoDaoImpl().insertBook(book);
		request.setAttribute("flag", "添加成功");
	
		request.getRequestDispatcher("book_manager.jsp").forward(request,response);
		
		
	}

}
