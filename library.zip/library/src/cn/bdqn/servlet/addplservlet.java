package cn.bdqn.servlet;

import java.io.IOException;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.bookscoreimpl;
import cn.bdqn.dao.Impl.discussDaoImpl;

/**
 * Servlet implementation class addplservlet
 */
@WebServlet("/addplservlet")
public class addplservlet extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		discussDaoImpl ds = new discussDaoImpl();
		String username=  request.getParameter("username");
		String bookname = request.getParameter("bookname");
		String content = request.getParameter("content");
		//Integer score = Integer.valueOf(request.getParameter("score"));
		Timestamp senddate = new Timestamp(new Date().getTime());
		ds.adddiscuss(bookname, content,0, senddate, username);
		String bookscore = ds.getscore(bookname);
		String page = request.getParameter("page");
		boolean userflag = new bookscoreimpl().getusername(bookname, username); 
		request.setAttribute("userflag", userflag);
		int allpage = ds.getallpage(bookname);
		int counts = ds.getcounts(bookname);
		List discusslist = ds.getdiscusslist(bookname,page);
		if(discusslist==null){
			request.getSession().setAttribute("page",page);
			request.getSession().setAttribute("allpage", allpage);
			request.getSession().setAttribute("counts", counts);
			request.getRequestDispatcher("pinglun.jsp").forward(request, response);
		}else{
		request.getSession().setAttribute("discusslist", discusslist);
		request.getSession().setAttribute("bookname", bookname);
		request.getSession().setAttribute("bookscore", bookscore);
		request.getSession().setAttribute("page",page);
		request.getSession().setAttribute("allpage", allpage);
		request.getSession().setAttribute("counts", counts);
		request.getRequestDispatcher("pinglun.jsp").forward(request, response);
		}
		
		
		
		
	}

}
