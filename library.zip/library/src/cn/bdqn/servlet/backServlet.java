package cn.bdqn.servlet;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.BookInfoDaoImpl;
import cn.bdqn.dao.Impl.ReaderDaoImpl;

/**
 * Servlet implementation class backServlet
 */
@WebServlet("/backServlet")
public class backServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer bookid = Integer.valueOf(request.getParameter("bookid"));
		
		String username = request.getParameter("username");
		
		Date date = new Date();
		
		Timestamp time = new Timestamp(date.getTime());
		
		new BookInfoDaoImpl().backbook(bookid, time);
		
		new ReaderDaoImpl().jianshaoshu(username);
		//response.sendRedirect("book_manager.jsp");
		
		request.getRequestDispatcher("/boomanservlet").forward(request, response);
		
	}

}
