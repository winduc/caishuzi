package cn.bdqn.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.BookInfoDaoImpl;

/**
 * Servlet implementation class boomanservlet
 */
@WebServlet("/boomanservlet")
public class boomanservlet extends HttpServlet {
	
	protected void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String page = ((request.getParameter("page")!=null)?(request.getParameter("page")+""):"1");
		String bookname = request.getParameter("bookname");
		String langu = request.getParameter("langu");
		int zongshu = new BookInfoDaoImpl().getcounts(bookname,langu);
		List list = new BookInfoDaoImpl().getSearchResult(bookname, page,langu);
		int allpage =new BookInfoDaoImpl().getallpage(bookname,langu);
		request.getSession().setAttribute("booklist", list);
		//System.out.println(list);
		request.getSession().setAttribute("bookname", bookname);
		request.setAttribute("page", page);
		//request.setAttribute("chushi", chushi);
		request.setAttribute("zongshu", zongshu);
		request.setAttribute("allpage", allpage);
		request.getRequestDispatcher("book_manager.jsp").forward(request, response);
		//System.out.println(allpage);
		//System.out.println(zongshu);
		
		}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		search(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		search(request, response);
	}
}
