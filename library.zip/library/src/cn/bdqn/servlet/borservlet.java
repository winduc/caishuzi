package cn.bdqn.servlet;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import cn.bdqn.dao.Impl.BookInfoDaoImpl;
import cn.bdqn.dao.Impl.ReaderDaoImpl;
import cn.bdqn.entity.Reader;
import cn.bdqn.service.Impl.BookInfoServiceImpl;
import cn.bdqn.service.Impl.ReaderServiceImpl;

/**
 * Servlet implementation class borservlet
 */
@WebServlet("/borservlet")
public class borservlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		Integer bookid = Integer.valueOf(request.getParameter("bookid"));
		String username = request.getParameter("username");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, 30);
		Timestamp time = new Timestamp(date.getTime());
		Timestamp times = new Timestamp(cal.getTime().getTime());
		//Reader reader = new ReaderDaoImpl().getReaderbyusername(username);
		new ReaderDaoImpl().zengjiashu(username);
		 //String page = request.getParameter("page");
		new BookInfoDaoImpl().borrowbook(bookid, username, time,times);
		//new ReaderDaoImpl().zengjiashu(username);
		 
		 String page = ((request.getParameter("page")!=null)?(request.getParameter("page")+""):"1");
		String langu = 	request.getParameter("langu");
		 String bookname = request.getParameter("bookname");
			int zongshu = new BookInfoDaoImpl().getcounts(bookname,langu);
			List list = new BookInfoDaoImpl().getSearchResult(bookname, page,langu);
			int allpage =new BookInfoDaoImpl().getallpage(bookname,langu);
			request.getSession().setAttribute("booklist", list);
			
			request.getSession().setAttribute("bookname", bookname);
			request.setAttribute("page", page);
			//request.setAttribute("chushi", chushi);
			request.setAttribute("zongshu", zongshu);
			request.setAttribute("allpage", allpage);
			request.setAttribute("sousuo", bookname);
			Reader reader = new ReaderDaoImpl().getReaderbyusername(username);
			request.getSession().setAttribute("reader", reader);
			request.getRequestDispatcher("Book.jsp").forward(request, response);
	}

}
