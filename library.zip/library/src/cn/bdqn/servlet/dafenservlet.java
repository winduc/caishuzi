package cn.bdqn.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.bookscoreimpl;
import cn.bdqn.dao.Impl.discussDaoImpl;

/**
 * Servlet implementation class dafenservlet
 */
@WebServlet("/dafenservlet")
public class dafenservlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String username=request.getParameter("username");
		String bookname= request.getParameter("bookname");
		String score = request.getParameter("score");
		
		
		String page = ((request.getParameter("page")!=null)?(request.getParameter("page")+""):"1");
		discussDaoImpl ds = new discussDaoImpl();
		//String username = (String)request.getSession().getAttribute("username");
		//String bookname = request.getParameter("bookname");
		//String username = request.getParameter("username");
		
		boolean userflag = new bookscoreimpl().getusername(bookname, username); 
		//System.out.println(userflag);
		if(!userflag){
		new bookscoreimpl().dafen(bookname, username, score);
		}
		
		request.setAttribute("userflag", new bookscoreimpl().getusername(bookname, username));
		int allpage = ds.getallpage(bookname);
		int counts = ds.getcounts(bookname);
		String bookscore = new bookscoreimpl().getscore(bookname);
		List discusslist = ds.getdiscusslist(bookname,page);
		if(discusslist==null){
			request.setAttribute("page",page);
			request.setAttribute("allpage", allpage);
			request.setAttribute("counts", counts);
			request.getRequestDispatcher("pinglun.jsp").forward(request, response);
		}else{
		request.setAttribute("discusslist", discusslist);
		request.getSession().setAttribute("bookname", bookname);
		request.getSession().setAttribute("bookscore", bookscore);
		request.setAttribute("page",page);
		request.setAttribute("allpage", allpage);
		request.setAttribute("counts", counts);
		request.getRequestDispatcher("pinglun.jsp").forward(request, response);
		}
	}
		
		//request.getRequestDispatcher("pinglun.jsp").forward(request, response);
		
		
	}


