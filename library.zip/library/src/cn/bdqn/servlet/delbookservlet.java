package cn.bdqn.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.BookInfoDaoImpl;

/**
 * Servlet implementation class delbookservlet
 */
@WebServlet("/delbookservlet")
public class delbookservlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	Integer bookid = Integer.valueOf(request.getParameter("bookid"));
	new BookInfoDaoImpl().delBook(bookid);	
	//request.getSession().invalidate();
	request.getRequestDispatcher("/boomanservlet").forward(request, response);
	
	
	}

	

}
