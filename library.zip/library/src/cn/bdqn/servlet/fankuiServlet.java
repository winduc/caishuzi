package cn.bdqn.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.stream.FileCacheImageInputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.jmx.snmp.Timestamp;

/**
 * Servlet implementation class fankuiServlet
 */
@WebServlet("/fankuiServlet")
public class fankuiServlet extends HttpServlet {
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String username = request.getParameter("username");
		
		//写入文件中
		String neirong=null;
		
		Timestamp tt = new Timestamp(System.currentTimeMillis());
		Date dt = new Date();
		File file = new File("d://fankui//"+username+".txt");
		DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 
		if(!file.exists()){
			neirong = df.format(dt.getTime())+request.getParameter("username")+":"+request.getParameter("fankui");
			byte zi[] = neirong.getBytes();
			file.createNewFile();
			FileOutputStream outstr = new FileOutputStream(file);
			outstr.write(zi);
			outstr.close();
		
		}else{
			FileOutputStream outstr = new FileOutputStream(file,true);
			 neirong = "\r\n"+df.format(dt.getTime())+request.getParameter("username")+":"+request.getParameter("fankui");
			byte zi[] = neirong.getBytes();
			
			outstr.write(zi);
			outstr.close();
		}
		//System.out.println(neirong);
		request.setAttribute("fkts", "提交完成。");
		request.getRequestDispatcher("fankui.jsp").forward(request, response);
	}

}
