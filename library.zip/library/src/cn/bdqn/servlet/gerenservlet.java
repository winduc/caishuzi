package cn.bdqn.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.BookInfoDaoImpl;
import cn.bdqn.dao.Impl.ReaderDaoImpl;
import cn.bdqn.entity.Reader;

/**
 * Servlet implementation class gerenservlet
 */
@WebServlet("/gerenservlet")
public class gerenservlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String username = request.getParameter("username");
		Reader reader = new ReaderDaoImpl().getReaderbyusername(username);
		request.getSession().removeAttribute("reader");
		request.getSession().removeAttribute("borrowlist");
		List borrowlist = new BookInfoDaoImpl().borrowlist(reader.getUsername());
		request.getSession().setAttribute("borrowlist", borrowlist);
		request.getSession().setAttribute("reader", reader);
		request.getRequestDispatcher("reader.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
