package cn.bdqn.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.BookInfoDaoImpl;
import cn.bdqn.dao.Impl.ReaderDaoImpl;
import cn.bdqn.dao.Impl.SystemManagerDaoImpl;
import cn.bdqn.entity.Reader;

/**
 * Servlet implementation class lateservlet
 */
@WebServlet("/lateservlet")
public class lateservlet extends HttpServlet {//延期servlet
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String bookid=request.getParameter("bookid");
		
		new SystemManagerDaoImpl().yanqi(bookid);
		
		//System.out.println(request.getSession().getAttribute("reader"));
		
		Reader reader  = (Reader)request.getSession().getAttribute("reader");
		
		List borrowlist = new BookInfoDaoImpl().borrowlist(reader.getUsername());
		
		request.getSession().removeAttribute("reader");
		
		request.getSession().removeAttribute("borrowlist");
		
		request.getSession().setAttribute("borrowlist", borrowlist);
		
		request.getSession().setAttribute("reader", reader);
		
		request.getRequestDispatcher("borrowcz.jsp").forward(request, response);
	}
	
	
	
	

}
