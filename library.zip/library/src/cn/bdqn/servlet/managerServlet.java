package cn.bdqn.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.SystemManagerDaoImpl;
import cn.bdqn.entity.SystemManager;
import cn.bdqn.service.Impl.SystemManagerServiceImpl;

/**
 * Servlet implementation class managerServlet
 */
@WebServlet("/managerServlet")
public class managerServlet extends HttpServlet {
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String pwd = request.getParameter("magpwd");
		SystemManager sys = new SystemManager(null, username,pwd);
		boolean flag = new SystemManagerServiceImpl().systemLogin(sys);
		if(!flag){
			request.setAttribute("flag", "帐号或密码错误！");
			request.getRequestDispatcher("manager.jsp").forward(request, response);
		}else{
			request.getSession().setAttribute("power","a");
			request.getRequestDispatcher("book_manager.jsp").forward(request, response);
		}
		
		
	}

}
