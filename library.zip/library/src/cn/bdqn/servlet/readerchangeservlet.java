package cn.bdqn.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.ReaderDaoImpl;
import cn.bdqn.entity.Reader;

/**
 * Servlet implementation class readerchangeservlet
 */
@WebServlet("/readerchangeservlet")
public class readerchangeservlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String password = request.getParameter("password");
		Integer age  = Integer.valueOf(request.getParameter("age"));
		String username = request.getParameter("username");
		Reader reader = new ReaderDaoImpl().getReaderbyusername(username);
		reader.setAge(age);
		reader.setPassword(password);
		new ReaderDaoImpl().updateReader(reader);
		request.getSession().setAttribute("reader",reader);
		request.setAttribute("ok", "修改成功。");
		request.getRequestDispatcher("aa.jsp").forward(request, response);
	}

}
