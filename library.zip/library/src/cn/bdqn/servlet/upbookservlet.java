package cn.bdqn.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.BookInfoDaoImpl;
import cn.bdqn.entity.BookInfo;

/**
 * Servlet implementation class upbookservlet
 */
@WebServlet("/upbookservlet")
public class upbookservlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		Integer bookid = Integer.valueOf(request.getParameter("bookid"));
		String bookauthor = request.getParameter("bookauthor");
		String bookname = request.getParameter("bookname");
		Integer langu = Integer.valueOf(request.getParameter("langu"));
		BookInfo book = new BookInfoDaoImpl().getbookbybookid(bookid);
		book.setBookauthor(bookauthor);
		book.setBookname(bookname);
		book.setLangu(langu);
		new BookInfoDaoImpl().updateBook(book);
		request.getSession().setAttribute("book", book);
		request.getRequestDispatcher("book_edit.jsp").forward(request,response);
		
		
	}

	
	
}
