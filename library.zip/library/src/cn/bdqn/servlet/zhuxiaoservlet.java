package cn.bdqn.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.bdqn.dao.Impl.ReaderDaoImpl;
import cn.bdqn.service.Impl.ReaderServiceImpl;

/**
 * Servlet implementation class zhuxiaoservlet
 */
@WebServlet("/zhuxiaoservlet")
public class zhuxiaoservlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String username = request.getParameter("username");
	
	boolean flag = new ReaderDaoImpl().zhuxiaoyanzheng(username);
	if(!flag){
		request.setAttribute("cuowu", "注销失败！");
		
		request.getRequestDispatcher("zhuxiao.jsp").forward(request, response);
	}else{
	
	//request.getSession().setAttribute("close","a");
	new ReaderServiceImpl().delreader(username);
	request.getSession().invalidate();
	response.sendRedirect("zxcg.jsp");	
	}
	}

}
