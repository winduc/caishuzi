package cn.bdqn.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class JdbcUtils {
	 
		 
		 private static ComboPooledDataSource cpds=null;
		 static{
		//helloc3p0 是配置文件中的name属性值，要对应
		   cpds = new ComboPooledDataSource("cp30");
		 }
		 
		 public static Connection getConnection1() throws SQLException{
		  Connection conn = cpds.getConnection();
		   return conn;
		 }
		 
		 /**
		 * 但是这种方式每次连接的时候还是每次都创建了一次连接了一次
		 * 并没有省事。可以将连接放到外面
		 * @return
		 * @throws SQLException
		 */
		 /*public static Connection getConnection1() throws SQLException{
		  ComboPooledDataSource cpds = new ComboPooledDataSource("helloc3p0");
		  Connection conn = cpds.getConnection();
		  return conn;
		 }*/
		 


	public static Connection getConnection(){
		 ComboPooledDataSource cpds=new ComboPooledDataSource("cp30");
		Connection con=null;
		try {
			con=cpds.getConnection();
			return con;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	public static void close(ResultSet rs,PreparedStatement ps,Connection con){
		//System.out.println(22);
		if (rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (ps!=null) {
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (con!=null) {
			try {
				con.close();
			//	System.out.println(1);
				//System.out.println(11);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		System.out.println(JdbcUtils.getConnection());
	}
}
