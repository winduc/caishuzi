package cn.bdqn.utils;

import java.util.List;

public class Page<T> {
private int pageNum;
private int pageSize;
private int totalPage;
private int totalRecord;
private int index;
private List<T> data;
public Page() {
	super();
	// TODO Auto-generated constructor stub
}
public Page(int pageNum, int pageSize, int totalPage, int totalRecord, int index, List<T> data) {
	super();
	this.pageNum = pageNum;
	this.pageSize = pageSize;
	this.totalPage = totalPage;
	this.totalRecord = totalRecord;
	this.index = index;
	this.data = data;
}
public int getPageNum() {
	return pageNum;
}
public void setPageNum(int pageNum) {
	this.pageNum = pageNum;
}
public int getPageSize() {
	return pageSize;
}
public void setPageSize(int pageSize) {
	this.pageSize = pageSize;
}
public int getTotalPage() {
	return totalPage;
}
public void setTotalPage(int totalPage) {
	this.totalPage = totalPage;
}
public int getTotalRecord() {
	return totalRecord;
}
public void setTotalRecord(int totalRecord) {
	this.totalRecord = totalRecord;
}
public int getIndex() {
	return index;
}
public void setIndex(int index) {
	this.index = index;
}
public List<T> getData() {
	return data;
}
public void setData(List<T> data) {
	this.data = data;
}
@Override
public String toString() {
	return "Page [pageNum=" + pageNum + ", pageSize=" + pageSize + ", totalPage=" + totalPage + ", totalRecord="
			+ totalRecord + ", index=" + index + ", data=" + data + "]";
}

}
