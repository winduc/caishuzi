package cn.bdqn.utils;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;

public class WebUtils {
public static <T>T param2Bean(HttpServletRequest request,T t){
	Map<String,String[]> map=request.getParameterMap();
	try {
		BeanUtils.populate(t, map);
	} catch (IllegalAccessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (InvocationTargetException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return t;
	
}
}
